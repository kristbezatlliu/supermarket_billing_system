/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package supermarket_billing_system;

/**
 *
 * @author User
 */
public class Supermarket_Billing_System {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        javax.swing.JFrame newmenu = new MainMenu();
        newmenu.setVisible(true);
    }
    
}
